Name of group members --

Abha Singh 
Kartik Pandit


65668298/ readme.txt      // Group members, and anything that the grader 
                     // needs to be aware of 
part1/ 
                 part1.bit // DON’T FORGET!!!! 
                part1_incorrect.jpg 
               dual_flop_1.0/ 
                   //src-- all vhdl files
part2/ 
                   // IP core from repository for part 1 with this exact 
                  // name. Make sure all VHDL is included 
            part2.bit // DON’T FORGET!!!! 
            handshake_1.0/ 
                         //src-- all vhdl files
            Screen Shot _ part2.jpg

part3/ 
                // IP core from repository for part 2 with this exact 
 
        part3.bit // DON’T FORGET!!!! 
       fifo_1.0/ // IP core from repository for part 3 with this ex
              //src-- all vhdl files

                 fifo.generator_0
                 fifo.genrator_1



       Screen Shot _ part3.jpg
